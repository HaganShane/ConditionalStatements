/**
 * @author Shane Hagan
 * Date: 11/25/2022
 * Project: Conditional Statements practice assignment
 */

package com.hagan.conditionalstatements;

import java.util.Scanner;

public class ConditionalStatements {

	public static void main(String[] args) {
		//Problem1();
		//Problem2();
		//Problem3();
		//Problem4();
		//determineGrade();
		//practiceSwitches();
		calculateTaxes();

	}
	
	public static void Problem1() {
		//int x = 7;
		int x = 15;
		if (x < 10) {
			System.out.println("Less than 10");
		}
	}
	
	public static void Problem2() {
		//int x = 7;
		int x = 15;
		if (x < 10) {
			System.out.println("Less than 10");
		}
		else {
			System.out.println("Greater than 10");
		}
	}
	
	public static void Problem3() {
		//int x = 15;
		int x = 50;
		if (x < 10) {
			System.out.println("Less than 10");
		}
		else if (x > 10 && x < 20){
			System.out.println("Between 10 and 20");
		}
		else if (x >= 20){
			System.out.println("Greater than or equal to 20");
		}
	}
	
	public static void Problem4() {
		//int x = 15;
		int x = 5;
		if (x < 10 || x > 20) {
			System.out.println("Out of range");
		}
		else if (x >= 10 && x <= 20){
			System.out.println("In range");
		}
	}
	
	public static void determineGrade() {
		Scanner input = new Scanner(System.in);
		
		System.out.println("Please input the student's grade: ");
		double grade = input.nextDouble();
		input.close();
		
		if (grade >= 90 && grade <= 100) {
			System.out.println("Your grade is an A!");
		}
		else if (grade >= 80 && grade <= 89) {
			System.out.println("Your grade is a B.");
		}
		else if (grade >= 70 && grade <= 79) {
			System.out.println("Your grade is a C.");
		}
		else if (grade >= 60 && grade <= 69) {
			System.out.println("Your grade is a D.");
		}
		else if (grade >= 0 && grade < 60) {
			System.out.println("Your grade is a F.");
		}
		else if (grade < 0 || grade > 100) {
			System.out.println("Score out of range.");
		}
	}

	public static void practiceSwitches() {
		Scanner input = new Scanner(System.in);
		
		System.out.println("Please input the day of the week: ");
		int day = input.nextInt();
		input.close();
		
		switch (day) {
			case 1: System.out.println("It is Monday."); break;
			case 2: System.out.println("It is Tuesday."); break;
			case 3: System.out.println("It is Wednesday."); break;
			case 4: System.out.println("It is Thursday."); break;
			case 5: System.out.println("It is Friday!"); break;
			case 6: System.out.println("It is Saturday!"); break;
			case 7: System.out.println("It is Sunday."); break;
			default: System.out.println("Out of range."); break;
		}
	}

	public static void calculateTaxes() {
	/**
	 * Get input from user and declare our variables
	 */
		Scanner input = new Scanner(System.in);
		
		System.out.println("Please input your tax status (Single = 1, Married Filing Jointly = 2, Married Filing Separately = 3, Head of Household = 4): ");
		int status = input.nextInt();
		
		/**
		 * If the status is invalid, display a message
		 */
		if (status <= 0 || status > 4) {
			System.out.println("Invalid status code, please enter one of the designated numbers");
			System.exit(-1);
		}
		
		System.out.println("Please input your taxable income to the nearest dollar amount: ");
		int taxableAmount = input.nextInt();
		input.close();
		
		double tax;
		

		
		/**
		 * If the status is 1 or Single, determine tax by using income and tax bracket
		 */
		if (status == 1) {
			if (taxableAmount < 0) {
				System.out.println("Invalid amount. Please retry with a valid amount");
			}
			else if (taxableAmount >= 0 && taxableAmount <= 8350) {
				tax = taxableAmount * .10;
				System.out.println("The tax you need to pay is: $" + tax);
			}
			else if (taxableAmount >= 8351 && taxableAmount <= 33950) {
				tax = (8350 * .10) + (taxableAmount - 8350) * (.15);
				System.out.println("The tax you need to pay is: $" + tax);
			}
			else if (taxableAmount >= 33951 && taxableAmount <= 82250) {
				tax = (8350 * .10) + ((33950 - 8350) * .15) + ((taxableAmount - 33950) * .25);
				System.out.println("The tax you need to pay is: $" + tax);
			}
			else if (taxableAmount >= 82251 && taxableAmount <= 171550) {
				tax = (8350 * .10) + ((33950 - 8350) * .15) + ((82250 - 33950) * .25) + ((taxableAmount - 82250) * .28);
				System.out.println("The tax you need to pay is: $" + tax);
			}
			else if (taxableAmount >= 171551 && taxableAmount <= 372950) {
				tax = (8350 * .10) + ((33950 - 8350) * .15) + ((82250 - 33950) * .25) + ((171550 - 82250) * .28) + ((taxableAmount - 171550) * .33);
				System.out.println("The tax you need to pay is: $" + tax);
			}
			else if (taxableAmount >= 372951) {
				tax = (8350 * .10) + ((33950 - 8350) * .15) + ((82250 - 33950) * .25) + ((171550 - 82250) * .28) + ((372950 - 171550) * .33) + ((taxableAmount - 372950) * .35);
				System.out.println("The tax you need to pay is: $" + tax);
			}
		}
		
		/**
		 * If the status is 2 or Married Filing Jointly, determine tax by using income and tax bracket
		 */
		else if (status == 2) {
			if (taxableAmount < 0) {
				System.out.println("Invalid amount. Please retry with a valid amount");
			}
			else if (taxableAmount >= 0 && taxableAmount <= 16700) {
				tax = taxableAmount * .10;
				System.out.println("The tax you need to pay is: $" + tax);
			}
			else if (taxableAmount >= 16701 && taxableAmount <= 67900) {
				tax = (16700 * .10) + (taxableAmount - 16700) * (.15);
				System.out.println("The tax you need to pay is: $" + tax);
			}
			else if (taxableAmount >= 67901 && taxableAmount <= 137050) {
				tax = (16700 * .10) + ((67900 - 16700) * .15) + ((taxableAmount - 67900) * .25);
				System.out.println("The tax you need to pay is: $" + tax);
			}
			else if (taxableAmount >= 137051 && taxableAmount <= 208850) {
				tax = (16700 * .10) + ((67900 - 16700) * .15) + ((137050 - 67900) * .25) + ((taxableAmount - 137050) * .28);
				System.out.println("The tax you need to pay is: $" + tax);
			}
			else if (taxableAmount >= 208851 && taxableAmount <= 372950) {
				tax = (16700 * .10) + ((67900 - 16700) * .15) + ((137050 - 67900) * .25) + ((208850 - 137050) * .28) + ((taxableAmount - 208850) * .33);
				System.out.println("The tax you need to pay is: $" + tax);
			}
			else if (taxableAmount >= 372951) {
				tax = (16700 * .10) + ((67900 - 16700) * .15) + ((137050 - 67900) * .25) + ((208850 - 137050) * .28) + ((372950 - 208850) * .33) + ((taxableAmount - 372950) * .35);
				System.out.println("The tax you need to pay is: $" + tax);
			}
		}
		
		/**
		 * If the status is 3 or Married Filing Separately, determine tax by using income and tax bracket
		 */
		else if (status == 3) {
			if (taxableAmount < 0) {
				System.out.println("Invalid amount. Please retry with a valid amount");
			}
			else if (taxableAmount >= 0 && taxableAmount <= 8350) {
				tax = taxableAmount * .10;
				System.out.println("The tax you need to pay is: $" + tax);
			}
			else if (taxableAmount >= 8351 && taxableAmount <= 33950) {
				tax = (8350 * .10) + (taxableAmount - 8350) * (.15);
				System.out.println("The tax you need to pay is: $" + tax);
			}
			else if (taxableAmount >= 33951 && taxableAmount <= 68525) {
				tax = (8350 * .10) + ((33950 - 8350) * .15) + ((taxableAmount - 33950) * .25);
				System.out.println("The tax you need to pay is: $" + tax);
			}
			else if (taxableAmount >= 68526 && taxableAmount <= 104425) {
				tax = (8350 * .10) + ((33950 - 8350) * .15) + ((68525 - 33950) * .25) + ((taxableAmount - 68525) * .28);
				System.out.println("The tax you need to pay is: $" + tax);
			}
			else if (taxableAmount >= 104426 && taxableAmount <= 186475) {
				tax = (8350 * .10) + ((33950 - 8350) * .15) + ((68525 - 33950) * .25) + ((104425 - 68525) * .28) + ((taxableAmount - 104425) * .33);
				System.out.println("The tax you need to pay is: $" + tax);
			}
			else if (taxableAmount >= 186476) {
				tax = (8350 * .10) + ((33950 - 8350) * .15) + ((68525 - 33950) * .25) + ((104425 - 68525) * .28) + ((186475 - 104425) * .33) + ((taxableAmount - 186475) * .35);
				System.out.println("The tax you need to pay is: $" + tax);
			}
		}
		
		/**
		 * If the status is 4 or Head of Household, determine tax by using income and tax bracket
		 */
		else if (status == 4) {
			if (taxableAmount < 0) {
				System.out.println("Invalid amount. Please retry with a valid amount");
			}
			else if (taxableAmount >= 0 && taxableAmount <= 11950) {
				tax = taxableAmount * .10;
				System.out.println("The tax you need to pay is: $" + tax);
			}
			else if (taxableAmount >= 11951 && taxableAmount <= 45500) {
				tax = (11950 * .10) + (taxableAmount - 11950) * (.15);
				System.out.println("The tax you need to pay is: $" + tax);
			}
			else if (taxableAmount >= 45501 && taxableAmount <= 117450) {
				tax = (11950 * .10) + ((45500 - 11950) * .15) + ((taxableAmount - 45500) * .25);
				System.out.println("The tax you need to pay is: $" + tax);
			}
			else if (taxableAmount >= 117451 && taxableAmount <= 190200) {
				tax = (11950 * .10) + ((45500 - 11950) * .15) + ((117450 - 45500) * .25) + ((taxableAmount - 117450) * .28);
				System.out.println("The tax you need to pay is: $" + tax);
			}
			else if (taxableAmount >= 190201 && taxableAmount <= 372950) {
				tax = (11950 * .10) + ((45500 - 11950) * .15) + ((117450 - 45500) * .25) + ((190200 - 117450) * .28) + ((taxableAmount - 190200) * .33);
				System.out.println("The tax you need to pay is: $" + tax);
			}
			else if (taxableAmount >= 372951) {
				tax = (11950 * .10) + ((45500 - 11950) * .15) + ((117450 - 45500) * .25) + ((190200 - 117450) * .28) + ((372950 - 190200) * .33) + ((taxableAmount - 372950) * .35);
				System.out.println("The tax you need to pay is: $" + tax);
			}
		}
		

	}
}
